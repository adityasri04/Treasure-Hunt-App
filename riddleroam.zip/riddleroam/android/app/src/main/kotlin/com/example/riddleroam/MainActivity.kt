package com.example.riddleroam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
